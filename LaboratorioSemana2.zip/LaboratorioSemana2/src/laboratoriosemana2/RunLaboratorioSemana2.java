/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package laboratoriosemana2;

/**
 *
 * @author rachm
 */
public class RunLaboratorioSemana2 {

    public static void main(String[] args) {
        Datos dt1 = new Datos();
        Datos dt2 = new Datos(8,9,6,7);
        Datos dt3 = new Datos("Jorge",8,9,6,7);
        System.out.println(dt3.getName());
    }
}