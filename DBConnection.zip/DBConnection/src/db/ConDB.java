package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConDB {
    
    private Connection conn;
    public ConDB(String host, int port, String database, String username, String password) {
        String url = "jdbc:mysql://localhost/pia_datos";

        try {
            conn = DriverManager.getConnection(url, "root", "");
            System.out.println("Conexión exitosa a la base de datos");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }
    
    public Connection getConnection() {
        return conn;
    }
    public void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Conexión cerrada correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
