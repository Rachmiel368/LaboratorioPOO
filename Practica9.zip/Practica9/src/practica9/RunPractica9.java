/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica9;


/**
 *
 * @author rachm
 */
public class RunPractica9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
            ClassIOArchivo wf = new ClassIOArchivo("C:\\Users\\211_7\\Desktop\\prueba.txt");
    }
    
}
